import processing.serial.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;

import org.json.JSONException;
import org.json.JSONObject;


final int BAUD_RATE = 230400;
final String serialName = "COM4";
Serial port;

int hour; 
int min;

PFont f;
PImage img;

String desiredLocation = "";

boolean button1;
boolean button2;
boolean record;


void setup() {
  //port = new Serial(this, serialName, BAUD_RATE); // open port
  size(800,600);
  background(255);
  
  //String data = link("https://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&key=AIzaSyDscFXxK5GytLm4PulloON9OeywNBhH1zc");
  // https://stackoverflow.com/questions/4308554/simplest-way-to-read-json-from-a-url-in-java
  
  img = loadImage("staticmap.png");
  textSize(20);  

}


void draw(){
      background(255);
      
      // text and line
      text(desiredLocation, 100, 100);
      fill(0);
      stroke(0);
      line(100,110,500,110);
      
      //button 1
      noFill();
      text("Mic", 530, 100);
      if(record){
         fill(0,255,0); 
      }
      rect(510, 80, 75, 30, 28);
      fill(0);
      noFill();
      
      
      
      //button 2
      text("→", 625, 100);
      rect(590, 80, 75, 30, 28);
  
  
    
    image(img, 100, 150);
    
    hour = hour();
    min = minute();
    
    if (hour < 10){
      
      // makes the hour i.e. 1 =  '0' , '1' when sending the bytes
     // port.write('0');
      //port.write(char(hour + '0'));
    }else{
      // make
      //port.write(char(hour/10 +'0'));
      //port.write(char(hour%10 + '0'));
    }
    if ( min < 10){
      // makes the min i.e. 7 =  '0' , '7' when sending the bytes
      //port.write('0');
      //port.write(char(min + '0'));
    }else{
      //port.write(char(min/10 +'0'));
      //port.write(char(min%10 + '0'));
    }

    
  
}


void mousePressed(){
  if (mouseX > 510 && mouseX < 585 && mouseY > 80 && mouseY < 110 && !record) {
        record = true;
        println("Started recording");
        //TODO 
        //Start recording
        
  }else if(mouseX > 510 && mouseX < 585 && mouseY > 80 && mouseY < 110){
        println("stopped recording");
        record = false;
        //TODO
        //stop recording
        // translate mp4 into word and make set the "desiredLocation" variable
  }
  
  // rect(590, 80, 75, 30, 28);
  if (mouseX> 590 && mouseX< 665 && mouseY > 80 && mouseY <110){
    println("sent");
  }
}


void keyTyped() {
  
  
  if(int(key) >= 32){
    desiredLocation = desiredLocation + Character.toString(key); 
    
  }if(int(key) == 8){
    if(desiredLocation.length() != 0)
      desiredLocation = desiredLocation.substring(0,desiredLocation.length()-1);
  }
  println(desiredLocation);
  
}
